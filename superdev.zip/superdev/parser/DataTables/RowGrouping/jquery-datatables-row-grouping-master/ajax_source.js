{ "aaData": [
	["Trident","Internet Explorer 4.0","Win 95+","4","X"],
	["Trident","Internet Explorer 5.0","Win 95+","5","C"],
	["Trident","Internet Explorer 5.5","Win 95+","5.5","A"],
	["Trident","Internet Explorer 6","Win 98+","6","A"],
	["Trident","Internet Explorer 7","Win XP SP2+","7","A"],
	["Trident","AOL browser (AOL desktop)","Win XP","6","A"],
	["Gecko","Firefox 1.0","Win 98+ / OSX.2+","1.7","A"],
	["Gecko","Firefox 1.5","Win 98+ / OSX.2+","1.8","A"]
] }